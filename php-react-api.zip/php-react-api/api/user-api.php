<?php
function getUsers(){
    $users = Users::readAll();
    echo json_encode($users);
}
?>