<?php
function getCategories(){
    echo json_encode(Categories::readAll());
}
function createCategory($data){
    $category = new Categories(null, $data["name"], $data["is_active"]);
    echo json_encode($category->create());
}
function getCategoriesBySearch($search){
    echo json_encode(Categories::readBySearch($search));
}

?>