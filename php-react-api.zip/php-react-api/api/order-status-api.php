<?php

function getOrderStatuss() {
    echo json_encode(OrderStatus::readAll());
}

function getOrderStatusById($_id) {
    echo json_encode(OrderStatus::readById($_id));
}

function createOrderStatus($data) {
    global $db;
    $obj = new OrderStatus(null, $data['name'] ?? '');
    echo json_encode(['result' => $obj->create()]);
}

function updateOrderStatus($_id, $data) {
    global $db;
    $obj = new OrderStatus($_id, $data['name'] ?? '');
    echo json_encode(['result' => $obj->update($_id)]);
}

function deleteOrderStatus($_id) {
    echo json_encode(['result' => OrderStatus::delete($_id)]);
}

?>