<?php

if ($endpoint == 'order-status' && $request == 'GET') {
    getOrderStatuss();
} elseif ($endpoint == 'order-statu' && $request == 'GET') {
    getOrderStatusById($_GET['id'] ?? 0);
} elseif ($endpoint == 'details-order-statu' && $request == 'GET') {
    getDetailsOrderStatus($_GET['id'] ?? 0);
} elseif ($endpoint == 'create-order-statu' && $request == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    createOrderStatus($data);
} elseif ($endpoint == 'edit-order-statu' && $request == 'PUT') {
    parse_str(file_get_contents('php://input'), $data);
    updateOrderStatus($_GET['id'] ?? 0, $data);
} elseif ($endpoint == 'delete-order-statu' && $request == 'DELETE') {
    deleteOrderStatus($_GET['id'] ?? 0);
}

?>