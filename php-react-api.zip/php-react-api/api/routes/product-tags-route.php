<?php

if ($endpoint == 'product-tags' && $request == 'GET') {
    getProductTagss();
} elseif ($endpoint == 'product-tag' && $request == 'GET') {
    getProductTagsById($_GET['id'] ?? 0);
} elseif ($endpoint == 'create-product-tag' && $request == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    createProductTags($data);
} elseif ($endpoint == 'edit-product-tag' && $request == 'PUT') {
    $data = json_decode(file_get_contents('php://input'), true);
    updateProductTags($_GET['id'] ?? 0, $data);
} elseif ($endpoint == 'delete-product-tag' && $request == 'DELETE') {
    deleteProductTags($_GET['id'] ?? 0);
}

?>