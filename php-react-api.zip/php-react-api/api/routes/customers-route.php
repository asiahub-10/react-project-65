<?php

if ($endpoint == 'customers' && $request == 'GET') {
    getCustomerss();
} elseif ($endpoint == 'customers-details' && $request == 'GET') {
    getCustomersById($_GET['id'] ?? 0);
} elseif ($endpoint == 'create-customers' && $request == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    createCustomers($data);
} elseif ($endpoint == 'edit-customers' && $request == 'PUT') {
    parse_str(file_get_contents('php://input'), $data);
    updateCustomers($_GET['id'] ?? 0, $data);
} elseif ($endpoint == 'delete-customers' && $request == 'DELETE') {
    deleteCustomers($_GET['id'] ?? 0);
}

?>