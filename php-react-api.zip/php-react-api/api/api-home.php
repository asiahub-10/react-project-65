<?php
// echo "API Working <br>";
require_once('../config/db.php');

// header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Origin: *");
// header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type");

// require_once('../models/products.class.php');
// require_once('../models/orders.class.php');
// OR
foreach (glob("../models/*.class.php") as $filename) {
    include_once($filename);
}
// include_once('product-api.php');
// include_once('order-api.php');
// OR
foreach(glob("*-api.php") as $filename) {
    include_once($filename);
}

$request = $_SERVER['REQUEST_METHOD'];
$endpoint = $_GET['method'] ?? null;

foreach (glob("routes/*-route.php") as $route) include_once($route);

if (!$endpoint) {
    echo json_encode(["error" => "No endpoint specified"]);
}

?>