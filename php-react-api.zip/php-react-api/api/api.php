<?php
// echo "API Working <br>";
require_once('../config/db.php');

// header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type");

// require_once('../models/products.class.php');
// require_once('../models/orders.class.php');
// OR
foreach (glob("../models/*.class.php") as $filename) {
    include_once($filename);
}
include_once('../helper/img-upload-helper.php');
include_once('../helper/jwt.php');

// include_once('product-api.php');
// include_once('order-api.php');
// OR
foreach(glob("*-api.php") as $filename) {
    include_once($filename);
}

$request = $_SERVER['REQUEST_METHOD'];
$endpoint = $_GET['method'] ?? null;

if($endpoint) {
    if($endpoint == 'roles' && $request == 'GET') {
        getRoles();
    } else if($endpoint == 'create-role' && $request == 'POST') {
        $data = json_decode(file_get_contents("php://input"),true);
        // echo json_encode(gettype($data));
        createRole($data);
    }    
    else if($endpoint == 'users' && $request == 'GET') {
        getUsers();
    }
    else if($endpoint == 'create-user' && $request == 'POST') {
        // echo json_encode($_POST);
        // echo json_encode($_FILES);
        createUser($_POST, $_FILES);
    }
    else if($endpoint == 'delete-user' && $request == 'DELETE') {
        // echo json_encode($_GET['id']);
        deleteUser($_GET['id']);
    }
    else if($endpoint == 'token' && $request == 'GET') {
        $data = [
            "name" => "Asia",
            "email" => "asia@example.com",
            "role" => "Admin"
        ];
        echo json_encode("Bearer token: ".generateJWT($data));
    }
    else{
        echo "This url '$endpoint' not found!";
    }    
    
}

?>