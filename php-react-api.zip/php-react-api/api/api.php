<?php
// echo "API Working <br>";
require_once('../config/db.php');

// header("Access-Control-Allow-Origin: http://localhost:5173");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

// require_once('../models/products.class.php');
// require_once('../models/orders.class.php');
// OR
foreach (glob("../models/*.class.php") as $filename) {
    include_once($filename);
}

// include_once('product-api.php');
// include_once('order-api.php');
// OR
foreach(glob("*-api.php") as $filename) {
    include_once($filename);
}
$request = $_SERVER['REQUEST_METHOD'];

if(isset($_GET['method'])) {
    $endpoint = $_GET['method'];
    // echo $method;
    if($endpoint == 'roles' && $request == 'GET') {
        getRoles();
    }
    else if($endpoint == 'create-role' && $request == 'POST') {
        $data = json_decode(file_get_contents("php://input"),true);
        // echo json_encode(gettype($data));
        createRole($data);
    }
    else if($endpoint == 'users') {
        echo "API Working - Users List";
    }else{
        echo "This url '$endpoint' not found!";
    }
    
    // if($method == 'products') {
    //     getProducts();
    // }elseif($method == 'product' && isset($_GET['id'])) {
    //     $id = $_GET['id'];
    //     getProductById($id);
    // }elseif($method == 'product-category' && isset($_GET['id'])) {
    //     $id = $_GET['id'];
    //     getProductByCategory($id);
    // }elseif($method == 'orders') {
    //     if(isset($_GET['pg'])) {
    //         $page = $_GET['pg'];
    //         getOrdersByPage($page);
    //     }else {
    //         getOrdersByPage(1);
    //     }
    //     // getOrdersByPage();
    // }
}

?>