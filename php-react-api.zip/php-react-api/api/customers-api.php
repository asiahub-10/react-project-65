<?php

function getCustomerss() {
    echo json_encode(Customers::readAll());
}

function getCustomersById($_id) {
    echo json_encode(Customers::readById($_id));
}

function createCustomers($data) {
    global $db;
    $obj = new Customers(null, $data['name'] ?? '', $data['email'] ?? '', $data['phone'] ?? '', $data['address'] ?? '');
    echo json_encode(['result' => $obj->create()]);
}

function updateCustomers($_id, $data) {
    global $db;
    $obj = new Customers($_id, $data['name'] ?? '', $data['email'] ?? '', $data['phone'] ?? '', $data['address'] ?? '');
    echo json_encode(['result' => $obj->update($_id)]);
}

function deleteCustomers($_id) {
    echo json_encode(['result' => Customers::delete($_id)]);
}

?>