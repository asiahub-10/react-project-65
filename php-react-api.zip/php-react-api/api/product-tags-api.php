<?php

function getProductTagss() {
    echo json_encode(ProductTags::readAll());
}

function getProductTagsById($_id) {
    echo json_encode(ProductTags::readById($_id));
}

function createProductTags($data) {
    $obj = new ProductTags(null, $data['title'] ?? '');
    echo json_encode(['result' => $obj->create()]);
}

function updateProductTags($_id, $data) {
    $obj = new ProductTags($_id, $data['title'] ?? '');
    echo json_encode(['result' => $obj->update($_id)]);
}

function deleteProductTags($_id) {
    echo json_encode(['result' => ProductTags::delete($_id)]);
}

?>