<?php
function getRoles() {
    echo json_encode(Roles::readAll());
}
function getRole($_id) {
    echo json_encode(Roles::readById($_id));
}
function createRole($data) {
    $role = new Roles(null, $data["name"]);
    echo json_encode($role->create());
}
function updateRole($data) {
    $role = new Roles($data["id"], $data["name"]);
    echo json_encode($role->update($data["id"]));
}
function deleteRole($_id) {
    echo json_encode(Roles::delete($_id));
}
?>