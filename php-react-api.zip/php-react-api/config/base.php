<?php
// define('BASE_URL', $_SERVER['DOCUMENT_ROOT'] . "/php_project/");
define('ADMIN_BASE', $_SERVER['DOCUMENT_ROOT'] . "/php_project/admin/");
// define('ADMIN_BASE_HTML', "/php_project/admin/");
const ADMIN_BASE_HTML = "/php_project/admin/";
// $num = 0;
?>