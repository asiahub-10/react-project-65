<?php
return [
    'secret_key_jwt' => 'idb65'
];
?>