import ManageProductTag from './components/pages/product-tags/ManageProductTag.tsx';
import CreateProductTag from './components/pages/product-tags/CreateProductTag.tsx';
import EditProductTag from './components/pages/product-tags/EditProductTag.tsx';
import DetailsProductTag from './components/pages/product-tags/DetailsProductTag.tsx';

// ProductTags Routes
{ path: '/product-tags', element: <ManageProductTag/> },
{ path: '/product-tags/create', element: <CreateProductTag/> },
{ path: '/product-tags/edit/:id', element: <EditProductTag/> },
{ path: '/product-tags/details/:id', element: <DetailsProductTag/> },
