import ManageUsers from './components/pages/users/ManageUsers.tsx';
import CreateUsers from './components/pages/users/CreateUsers.tsx';
import EditUsers from './components/pages/users/EditUsers.tsx';
import DetailsUsers from './components/pages/users/DetailsUsers.tsx';

import ManageOrderStatus from './components/pages/order-status/ManageOrderStatus.tsx';
import CreateOrderStatus from './components/pages/order-status/CreateOrderStatus.tsx';
import EditOrderStatus from './components/pages/order-status/EditOrderStatus.tsx';
import DetailsOrderStatus from './components/pages/order-status/DetailsOrderStatus.tsx';

import ManageCustomers from './components/pages/customers/ManageCustomers.tsx';
import CreateCustomers from './components/pages/customers/CreateCustomers.tsx';
import EditCustomers from './components/pages/customers/EditCustomers.tsx';
import DetailsCustomers from './components/pages/customers/DetailsCustomers.tsx';



// Customers Routes
  {path: '/customers', element: <ManageCustomers/>},
  {path: '/create-customer', element: <CreateCustomers/>},
  {path: '/customer/edit/:id', element: <EditCustomers/>},
  {path: '/customer/details/:id', element: <DetailsCustomers/>},


// OrderStatus Routes
  {path: '/order-status', element: <ManageOrderStatus/>},
  {path: '/create-order-statu', element: <CreateOrderStatus/>},
  {path: '/order-statu/edit/:id', element: <EditOrderStatus/>},
  {path: '/order-statu/details/:id', element: <DetailsOrderStatus/>},


// Users Routes
  {path: '/users', element: <ManageUsers/>},
  {path: '/create-user', element: <CreateUsers/>},
  {path: '/user/edit/:id', element: <EditUsers/>},
  {path: '/user/details/:id', element: <DetailsUsers/>},
