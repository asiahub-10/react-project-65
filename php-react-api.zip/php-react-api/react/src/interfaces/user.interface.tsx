export interface User {
  id: number,
  name?: string,
  email?: string,
  password: string,
  roleId?: number,
  address?: string,
  photo: File | null,
}

const userDefault: User = {
  id: 0,
  name: "",
  email: "",
  password: "",
  roleId: 0,
  address: "",
  photo: null,
};

export default userDefault;
