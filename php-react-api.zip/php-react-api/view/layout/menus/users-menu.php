<li class="nav-item">
  <a href="users" class="nav-link">
    <i class="nav-icon far fa-circle"></i>
    <p>
      Users
    </p>
  </a>
</li>
