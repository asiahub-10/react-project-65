<li class="nav-item">
  <a href="roles" class="nav-link">
    <i class="nav-icon far fa-circle"></i>
    <p>
      Roles
    </p>
  </a>
</li>
