<li class="nav-item">
  <a href="order-status" class="nav-link">
    <i class="nav-icon far fa-circle"></i>
    <p>
      Order Status
    </p>
  </a>
</li>
