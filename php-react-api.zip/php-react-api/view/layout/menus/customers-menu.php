<li class="nav-item">
  <a href="customers" class="nav-link">
    <i class="nav-icon far fa-circle"></i>
    <p>
      Customers
    </p>
  </a>
</li>
